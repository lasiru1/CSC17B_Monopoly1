<?php 
session_start();

if(isset($_SESSION['user_type'])){
    if($_SESSION['user_type'] == 'user'){
        include ('includes/Header.php');
    }else if($_SESSION['user_type'] == 'admin'){
        include ('includes/HeaderAdmin.php');
    }
}else{
    include ('includes/Header.php');
}

?>
<h1>Monopoly Rules</h1>
<p>This is where you'll put the rules/instructions</p>
<p>This is where you'll put the rules/instructions</p>
<p>This is where you'll put the rules/instructions</p>
<p>This is where you'll put the rules/instructions</p>
<p>This is where you'll put the rules/instructions</p>
<p>This is where you'll put the rules/instructions</p>
<p>This is where you'll put the rules/instructions</p>
<p>This is where you'll put the rules/instructions</p>
<p>This is where you'll put the rules/instructions</p>

<?php
include ('includes/Footer.php');
?>
