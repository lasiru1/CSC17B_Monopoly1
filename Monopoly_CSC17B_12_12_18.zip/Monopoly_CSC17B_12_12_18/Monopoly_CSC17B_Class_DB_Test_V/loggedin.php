<?php # Script 12.13 - loggedin.php #3
// The user is redirected here from login.php.

session_start(); // Start the session.

// If no session value is present, redirect the user:
// Also validate the HTTP_USER_AGENT!
if (!isset($_SESSION['agent']) OR ($_SESSION['agent'] != md5($_SERVER['HTTP_USER_AGENT']) )) {

	// Need the functions:
	require ('includes/login_functions.inc.php');
	redirect_user();	

}

// Set the page title and include the HTML header:
if(isset($_SESSION['user_type'])){
    if($_SESSION['user_type'] == 'user'){
        include ('includes/Header.php');
    }else if($_SESSION['user_type'] == 'admin'){
        include ('includes/HeaderAdmin.php');
    }
}else{
    include ('includes/Header.php');
}


// Print a customized message:
echo "<h1>Logged In!</h1>
<p id=\"login_mess\">You are now logged in, {$_SESSION['first_name']}, {$_SESSION['user_type']} !</p>
<div id=\"navigation_playgame\"> <a href=\"player.php\">Play Game</a><div>";

include ('includes/Footer.php');
?>