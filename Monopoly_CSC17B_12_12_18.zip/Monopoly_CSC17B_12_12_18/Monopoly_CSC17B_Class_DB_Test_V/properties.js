
//objects for all properties in the game
var properties = []
properties[0] = {
    group: 'go',
    name:'go'
}
properties[1] = {
	group: 'purple',
	name: 'Mediteranean Avenue',
	price: 60,
	rent: 2,
	totalHousing: 0, 
	totalHotels: 0,
	housePrice: 50,
	rent1House: 10,
	rent2House: 30,
	rent3House: 90,
	rent4House: 160,
	rentHotel: 250,
	mortgage: 30,
	mortgaged: false,	
	owner: 'none'
	}
properties[2] = {
		group: 'etc',
        type: "community",
		name: 'Community Chest 1'
	}
properties[3] ={
	group: 'purple',
	name: 'Baltic Avenue',
	price: 60,
	rent: 2,
	totalHousing: 0, 
	totalHotels: 0,
	housePrice: 50,
	rent1House: 20,
	rent2House: 60,
	rent3House: 180,
	rent4House: 320,
	rentHotel: 450,
	mortgage: 30,
	mortgaged: false,
	owner: 'none'
	}
properties[4] ={
    name: 'Income Tax',
	group: "tax",
	price: 200
}
properties[5] = {			//dont forget if statements for multiple railroads for rent
	group: 'railroad',
	name: 'Reading railroad',
	price: 200,
	rent: 25,	
	mortgage: 100,
	mortgaged: false,
	owner: 'none'
}
properties[6] ={	
	group: 'teal',
	name: 'Oriental Avenue',
	price: 100,
	rent: 6,
	totalHousing: 0, 
	totalHotels: 0,
	housePrice: 50,
	rent1House: 30,
	rent2House: 90,
	rent3House: 270,
	rent4House: 400,
	rentHotel: 550,
	mortgage: 50,
	mortgaged: false,
	owner: 'none'
	}
properties[7] ={
	group: 'etc',
    type: 'chance',
	name: 'Chance 1'
}
properties[8] ={
	group: 'teal',
	name: 'Vermont Avenue',
	price: 120,
	rent: 6,
	totalHousing: 0, 
	totalHotels: 0,
	housePrice: 50,
	rent1House: 30,
	rent2House: 90,
	rent3House: 270,
	rent4House: 400,
	rentHotel: 550,
	mortgage: 50,
	mortgaged: false,
	owner: 'none'
	}
properties[9] ={
	group: 'teal',
	name: 'Connecticut Avenue',
	price: 120,
	rent: 8,
	totalHousing: 0, 
	totalHotels: 0,
	housePrice: 50,
	rent1House: 40,
	rent2House: 100,
	rent3House: 300,
	rent4House: 450,
	rentHotel: 600,
	mortgage: 60,
	mortgaged: false,
	owner: 'none'
	}
properties[10] = {
    name:"Jail",
    group: "jail"
    
}
properties[11] = {
	group: 'pink',
	name: 'St Charles Place',
	price: 140,
	rent: 10,
	totalHousing: 0, 
	totalHotels: 0,
	housePrice: 100,
	rent1House: 50,
	rent2House: 150,
	rent3House: 450,
	rent4House: 625,
	rentHotel: 750,
	mortgage: 70,
	mortgaged: false,
	owner: 'none'
}
properties[12] = {			//utilities rent based on dice roll. statements needed to find out actual cost.
	group: 'utility',
	name: 'Electric Company',
	price: 150,
	rent: 10,	
	mortgage: 75,
	mortgaged: false,
	owner: 'none',
	costOneUtil: 4,
	costTwoUtil: 10
}
properties[13] = {
	group: 'pink',
	name: 'States Avenue',
	price: 140,
	rent: 10,
	totalHousing: 0, 
	totalHotels: 0,
	housePrice: 100,
	rent1House: 50,
	rent2House: 150,
	rent3House: 450,
	rent4House: 625,
	rentHotel: 750,
	mortgage: 70,
	mortgaged: false,
	owner: 'none'
}
properties[14] = {
	group: 'pink',
	name: 'Virginia Avenue',
	price: 160,
	rent: 12,
	totalHousing: 0, 
	totalHotels: 0,
	housePrice: 100,
	rent1House: 60,
	rent2House: 180,
	rent3House: 500,
	rent4House: 700,
	rentHotel: 900,
	mortgage: 80,
	mortgaged: false,
	owner: 'none'
}
properties[15] = {			
	group: 'railroad',
	name: 'Pennsylvania railroad',
	price: 200,
	rent: 25,	
	mortgage: 100,
	mortgaged: false,
	owner: 'none'
}
properties[16] = {
	group: 'orange',
	name: 'St James Place',
	price: 180,
	rent: 14,
	totalHousing: 0, 
	totalHotels: 0,
	housePrice: 100,
	rent1House: 70,
	rent2House: 200,
	rent3House: 550,
	rent4House: 750,
	rentHotel: 950,
	mortgage: 90,
	mortgaged: false,
	owner: 'none'
}
properties[17] = {
		group: 'etc',
        type: 'community',
		name: 'Community Chest 2'
	}
properties[18] = {
	group: 'orange',
	name: 'Tennessee Avenue',
	price: 180,
	rent: 14,
	totalHousing: 0, 
	totalHotels: 0,
	housePrice: 100,
	rent1House: 70,
	rent2House: 200,
	rent3House: 550,
	rent4House: 750,
	rentHotel: 950,
	mortgage: 90,
	mortgaged: false,
	owner: 'none'
}
properties[19] = {
	group: 'orange',
	name: 'New York Avenue',
	price: 200,
	rent: 16,
	totalHousing: 0, 
	totalHotels: 0,
	housePrice: 100,
	rent1House: 80,
	rent2House: 220,
	rent3House: 600,
	rent4House: 800,
	rentHotel: 1000,
	mortgage: 100,
	mortgaged: false,
	owner: 'none'
}
properties[20] ={
    group: 'parking',
    name: 'parking'
}
properties[21] = {
	group: 'red',
	name: 'Kentucky Avenue',
	price: 220,
	rent: 18,
	totalHousing: 0, 
	totalHotels: 0,
	housePrice: 150,
	rent1House: 90,
	rent2House: 250,
	rent3House: 700,
	rent4House: 875,
	rentHotel: 1050,
	mortgage: 110,
	mortgaged: false,
	owner: 'none'
}
properties[22] = {
	group: 'etc',
    type: 'chance',
	name: 'Chance 2'
}
properties[23] = {
	group: 'red',
	name: 'Indiana Avenue',
	price: 220,
	rent: 18,
	totalHousing: 0, 
	totalHotels: 0,
	housePrice: 150,
	rent1House: 90,
	rent2House: 250,
	rent3House: 700,
	rent4House: 875,
	rentHotel: 1050,
	mortgage: 110,
	mortgaged: false,
	owner: 'none'
}
properties[24] = {
	group: 'red',
	name: 'Illinois Avenue',
	price: 240,
	rent: 20,
	totalHousing: 0, 
	totalHotels: 0,
	housePrice: 150,
	rent1House: 100,
	rent2House: 300,
	rent3House: 750,
	rent4House: 925,
	rentHotel: 1100,
	mortgage: 120,
	mortgaged: false,
	owner: 'none'
}
properties[25] = {			
	group: 'railroad',
	name: 'B and O railroad',
	price: 200,
	rent: 25,	
	mortgage: 100,
	mortgaged: false,
	owner: 'none'
}
properties[26] = {
	group: 'yellow',
	name: 'Atlantic Avenue',
	price: 260,
	rent: 22,
	totalHousing: 0, 
	totalHotels: 0,
	housePrice: 150,
	rent1House: 110,
	rent2House: 330,
	rent3House: 800,
	rent4House: 975,
	rentHotel: 1150,
	mortgage: 130,
	mortgaged: false,
	owner: 'none'
}
properties[27] = {
	group: 'yellow',
	name: 'Ventnor Avenue',
	price: 260,
	rent: 22,
	totalHousing: 0, 
	totalHotels: 0,
	housePrice: 150,
	rent1House: 110,
	rent2House: 330,
	rent3House: 800,
	rent4House: 975,
	rentHotel: 1150,
	mortgage: 130,
	mortgaged: false,
	owner: 'none'
}
properties[28] = {			
	group: 'utility',
	name: 'Water Works',
	price: 150,
	rent: 10,	
	mortgage: 75,
	mortgaged: false,
	owner: 'none',
	costOneUtil: 4,
	costTwoUtil: 10
}
properties[29] = {
	group: 'yellow',
	name: 'Marvin Gardens',
	price: 280,
	rent: 24,
	totalHousing: 0, 
	totalHotels: 0,
	housePrice: 150,
	rent1House: 120,
	rent2House: 360,
	rent3House: 850,
	rent4House: 1025,
	rentHotel: 1200,
	mortgage: 140,
	mortgaged: false,
	owner: 'none'
}
properties[30] = {
	group: 'jail', 
	name: 'Go To Jail'
}
properties[31] = {
	group: 'green',
	name: 'Pacific Avenue',
	price: 300,
	rent: 26,
	totalHousing: 0, 
	totalHotels: 0,
	housePrice: 200,
	rent1House: 130,
	rent2House: 390,
	rent3House: 900,
	rent4House: 1100,
	rentHotel: 1275,
	mortgage: 150,
	mortgaged: false,
	owner: 'none'
}
properties[32] = {
	group: 'green',
	name: 'North Carolina Avenue',
	price: 300,
	rent: 26,
	totalHousing: 0, 
	totalHotels: 0,
	housePrice: 200,
	rent1House: 130,
	rent2House: 390,
	rent3House: 900,
	rent4House: 1100,
	rentHotel: 1275,
	mortgage: 150,
	mortgaged: false,
	owner: 'none'
}
properties[33] = {
		group: 'etc',
    type: 'community',
		name: 'Community Chest 3'
	}
properties[34] = {
	group: 'green',
	name: 'Pennsylvania Avenue',
	price: 320,
	rent: 28,
	totalHousing: 0, 
	totalHotels: 0,
	housePrice: 200,
	rent1House: 150,
	rent2House: 450,
	rent3House: 1000,
	rent4House: 1200,
	rentHotel: 1400,
	mortgage: 160,
	mortgaged: false,
	owner: 'none'
}
properties[35] = {			
	group: 'railroad',
	name: 'Short Line railroad',
	price: 200,
	rent: 25,	
	mortgage: 100,
	mortgaged: false,
	owner: 'none'
}
properties[36] = {
	group: 'etc',
    type: 'chance',
	name: 'Chance 3'
}
properties[37] = {
	group: 'blue',
	name: 'Park Place',
	price: 350,
	rent: 35,
	totalHousing: 0, 
	totalHotels: 0,
	housePrice: 200,
	rent1House: 175,
	rent2House: 500,
	rent3House: 1100,
	rent4House: 1300,
	rentHotel: 1500,
	mortgage: 175,
	mortgaged: false,
	owner: 'none'
}
properties[38] ={
    group: "tax",
    name: "Luxury Tax",
    price: 100
}
properties[39] = {
	group: 'blue',
	name: 'Boardwalk',
	price: 400,
	rent: 50,
	totalHousing: 0, 
	totalHotels: 0,
	housePrice: 200,
	rent1House: 200,
	rent2House: 600,
	rent3House: 1400,
	rent4House: 1700,
	rentHotel: 2000,
	mortgage: 200,
	mortgaged: false,
	owner: 'none'
}
function checkPlyrPosForProp()		//check to see if property is owner/purchasable
{
	var plyrPos = plyrPositionCheck();
	if (properties[plyrPos].owner === 'none')	
		return true;
	else	
		return false;
}
function getPropOwner()				//checks for property owner
{
	var PlyrsPos = plyrPositionCheck();
	return properties[PlyrsPos].owner;
}
function getPlyrRent()				//checks who owns the property and returns amount owed
{	
	//var plyrPosition = getPropOwner(); idk why this was here
    var plyrPosition = plyrPositionCheck();
	if (properties[plyrPosition].totalHousing > 0 || properties[plyrPosition].totalHotels === 1) {
		if (properties[plyrPosition].totalHousing === 1)
			return properties[plyrPosition].rent1House;
		if (properties[plyrPosition].totalHousing === 2)
			return properties[plyrPosition].rent2House;
		if (properties[plyrPosition].totalHousing === 3)
			return properties[plyrPosition].rent3House;
		if (properties[plyrPosition].totalHousing === 4)
			return properties[plyrPosition].rent4House;
		if (properties[plyrPosition].totalHotels === 1)
			return properties[plyrPosition].rentHotel;
		if (properties[plyrPosition].group === 'utility') {
			if (properties[12].owner === properties[28].owner) {
				return player[plyrTurn].lastRoll1*10+player[plyrTurn].lastRoll2*10; //diceroll * 10
			}
			else
				return player[plyrTurn].lastRoll1*4+player[plyrTurn].lastRoll2*4;  //diceroll * 4
		}
	}
	else
		return properties[plyrPosition].rent;
}
function canPayFee(fee){    
	if(currentPlyrMoney() >= fee)
		return true;
	else 
		return false;
}
function canBuyProp()			//checks if current player can buy property
{
	var playerPosCheck = player[plyrTurn].position;
	if(currentPlyrMoney() >= returnPropCost())
		return true;
	else 
		return false;
}
function buyProp()				//allows current player to buy property
{
	var plyrTurn = checkPlyrTurn();
	var plyrPosition = player[plyrTurn].position;
	var cost = returnPropCost();
	if(canBuyProp())
	{
        console.log("bought");
        console.log("money b4: "+player[plyrTurn].money);
		newMoney(-1 * (cost));
        console.log("money after: "+player[plyrTurn].money);
		properties[plyrPosition].owner = plyrTurn;
        hideBuySell();
        updateScore();
	}else{
        console.log("money too low! must pass");
    }
}
function pass(){
    console.log("player passing");
    hideBuySell();
        
}
/*
function canMortProp()     //checks if current player can mortgage property
{
	var plyrPstn = player[plyrTurn].position;
	if(properties[plyrPstn].mortgaged)
		return false
	else 
		return true;
}
*/
function mortProp()		//allows current player to mortgage property(work in progress)
{
	if(currentPlyrMoney() > properties[plyrPostn].mortgage)
	{
		newMoney(addMoney);
		properties[plyrPostn].mortgaged = true;
	}
}
function returnGroupName()
{
	var plyrPos = playerPosCheck();
	return properties[plyrPos].group;
}
function unMortProp()	////allows current player to unmortgage property(work in progress)
{
	var mortProps = [];
	var counter = 0;
	for (var i = 0; i < 40; i++) {
		if(properties[i].mortgaged === true) {
			mortProps[counter] = i;
			counter ++;
		}
	}
	var targetedProperty = x;
	if (canMortProp()) {
		var addMoneys = properties[targetedProperty].mortgage;
		newMoney(-1 * (addMoneys));
		properties[plyrPostn].mortgaged = false;
	}
}
function returnPropCost()		//returns cost of property for purchasing
{
	var propTar = player[plyrTurn].position;
	return properties[propTar].price;
}
function sellProp(targetedProp)
{
	var propTargeted = targetedProp;
	properties[targetedProp].owned = 'none';
}
function checkIfPayRent()
{
	var money = currentPlyrMoney();
	var rentCost = getPlyrRent();
	if(money >= rentCost)
		return true;
	else 
		return false;
}