<?php
session_start();
?>

<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>TODO supply a title</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" type="text/css" href="includes/CSS_PieceSelect.css">
        <link rel="stylesheet" type="text/css" href="includes/CSS_logoutButton.css">
        
    </head>
    <body>
        
        
        
        
        <script type="text/javascript">
            window.onload = function(){
                localStorage.setItem('player', document.location.href);
            };


                     
        </script>
        
                   <div id="navigation_logout">
            <ul>

                    <li><?php // Create a login/logout link:
                        if (isset($_SESSION['user_id'])) {
                                echo '<a href="logout.php"> Logout </a>';
                        } else {
                                echo '<a href="login.php"> Login </a>';
                        }
                        ?>
                    </li>


            </ul>
	</div>

            <form action="main_page.php" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
                <br><br>
                <label class="container">
                    <input type="radio" name="Plyr1" value="Wheelbarrow"><img class="picSize" src="Pieces/Wheelbarrow.png" alt="" >
                    <span class="checkmark"></span>
                </label>
                <label class="container">
                    <input type="radio" name="Plyr1" value="Thimble"><img class="picSize" src="Pieces/Thimble.png" alt="" >
                    <span class="checkmark"></span>
                </label>
                <label class="container">
                    <input type="radio" name="Plyr1" value="Racecar"><img class="picSize" src="Pieces/Racecar.png" alt="" >
                    <span class="checkmark"></span>
                </label>
                
                <label class="container">
                    <input type="radio" name="Plyr1" value="Iron"><img class="picSize" src="Pieces/Iron.png" alt="" >
                    <span class="checkmark"></span>
                </label>
                <label class="container">
                    <input type="radio" name="Plyr1" value="Hat"><img class="picSize" src="Pieces/Hat.png" alt="" >
                    <span class="checkmark"></span>
                </label>
                <label class="container">
                    <input type="radio" name="Plyr1" value="Dog"><img class="picSize" src="Pieces/Dog.png" alt="" >
                    <span class="checkmark"></span>
                </label>
                <label class="container">
                    <input type="radio" name="Plyr1" value="Boot"><img class="picSize" src="Pieces/Boot.png" alt="" >
                    <span class="checkmark"></span>
                </label>
                <label class="container">
                    <input type="radio" name="Plyr1" value="Battleship"><img class="picSize" src="Pieces/Battleship.png" alt="" >
                    <span class="checkmark"></span>
                    
                </label>
                Player 1 piece
                <br><br>

                <br><br>
                <label class="container">
                    <input type="radio" name="Plyr2" value="Wheelbarrow"><img class="picSize" src="Pieces/Wheelbarrow.png" alt="" >
                    <span class="checkmark"></span>
                </label>
                <label class="container">
                    <input type="radio" name="Plyr2" value="Thimble"><img class="picSize" src="Pieces/Thimble.png" alt="" >
                    <span class="checkmark"></span>
                </label>
                <label class="container">
                    <input type="radio" name="Plyr2" value="Racecar"><img class="picSize" src="Pieces/Racecar.png" alt="" >
                    <span class="checkmark"></span>
                </label>
                
                <label class="container">
                    <input type="radio" name="Plyr2" value="Iron"><img class="picSize" src="Pieces/Iron.png" alt="" >
                    <span class="checkmark"></span>
                </label>
                <label class="container">
                    <input type="radio" name="Plyr2" value="Hat"><img class="picSize" src="Pieces/Hat.png" alt="" >
                    <span class="checkmark"></span>
                </label>
                <label class="container">
                    <input type="radio" name="Plyr2" value="Dog"><img class="picSize" src="Pieces/Dog.png" alt="" >
                    <span class="checkmark"></span>
                </label>
                <label class="container">
                    <input type="radio" name="Plyr2" value="Boot"><img class="picSize" src="Pieces/Boot.png" alt="" >
                    <span class="checkmark"></span>
                </label>
                <label class="container">
                    <input type="radio" name="Plyr2" value="Battleship"><img class="picSize" src="Pieces/Battleship.png" alt="" >
                    <span class="checkmark"></span>
                </label>
                Player 2 piece
                <br><br>

                                <br><br>
                <label class="container">
                    <input type="radio" name="Plyr3" value="Wheelbarrow"><img class="picSize" src="Pieces/Wheelbarrow.png" alt="" >
                    <span class="checkmark"></span>
                </label>
                <label class="container">
                    <input type="radio" name="Plyr3" value="Thimble"><img class="picSize" src="Pieces/Thimble.png" alt="" >
                    <span class="checkmark"></span>
                </label>
                <label class="container">
                    <input type="radio" name="Plyr3" value="Racecar"><img class="picSize" src="Pieces/Racecar.png" alt="" >
                    <span class="checkmark"></span>
                </label>
                
                <label class="container">
                    <input type="radio" name="Plyr3" value="Iron"><img class="picSize" src="Pieces/Iron.png" alt="" >
                    <span class="checkmark"></span>
                </label>
                <label class="container">
                    <input type="radio" name="Plyr3" value="Hat"><img class="picSize" src="Pieces/Hat.png" alt="" >
                    <span class="checkmark"></span>
                </label>
                <label class="container">
                    <input type="radio" name="Plyr3" value="Dog"><img class="picSize" src="Pieces/Dog.png" alt="" >
                    <span class="checkmark"></span>
                </label>
                <label class="container">
                    <input type="radio" name="Plyr3" value="Boot"><img class="picSize" src="Pieces/Boot.png" alt="" >
                    <span class="checkmark"></span>
                </label>
                <label class="container">
                    <input type="radio" name="Plyr3" value="Battleship"><img class="picSize" src="Pieces/Battleship.png" alt="" >
                    <span class="checkmark"></span>
                </label>

                Player 3 piece
                <br><br>

                                <br><br>
                <label class="container">
                    <input type="radio" name="Plyr4" value="Wheelbarrow"><img class="picSize" src="Pieces/Wheelbarrow.png" alt="" >
                    <span class="checkmark"></span>
                </label>
                <label class="container">
                    <input type="radio" name="Plyr4" value="Thimble"><img class="picSize" src="Pieces/Thimble.png" alt="" >
                    <span class="checkmark"></span>
                </label>
                <label class="container">
                    <input type="radio" name="Plyr4" value="Racecar"><img class="picSize" src="Pieces/Racecar.png" alt="" >
                    <span class="checkmark"></span>
                </label>
                
                <label class="container">
                    <input type="radio" name="Plyr4" value="Iron"><img class="picSize" src="Pieces/Iron.png" alt="" >
                    <span class="checkmark"></span>
                </label>
                <label class="container">
                    <input type="radio" name="Plyr4" value="Hat"><img class="picSize" src="Pieces/Hat.png" alt="" >
                    <span class="checkmark"></span>
                </label>
                <label class="container">
                    <input type="radio" name="Plyr4" value="Dog"><img class="picSize" src="Pieces/Dog.png" alt="" >
                    <span class="checkmark"></span>
                </label>
                <label class="container">
                    <input type="radio" name="Plyr4" value="Boot"><img class="picSize" src="Pieces/Boot.png" alt="" >
                    <span class="checkmark"></span>
                </label>
                <label class="container">
                    <input type="radio" name="Plyr4" value="Battleship"><img class="picSize" src="Pieces/Battleship.png" alt="" >
                    <span class="checkmark"></span>
                </label>
                Player 4 piece
                <br><br>
                
                <input class="button" name="Submit" type="submit" />

            </form>

       
        
        
        
    </body>
</html>
