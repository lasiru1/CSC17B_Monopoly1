<?php
session_start();
?>
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>TODO supply a title</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <link rel="stylesheet" type="text/css" href="index.css">
    </head>
    <body>
        <div id="navigation_logout">
            <ul>

                    <li><?php // Create a login/logout link:
                        if (isset($_SESSION['user_id'])) {
                                echo '<a href="logout.php"> Logout </a>';
                        } else {
                                echo '<a href="login.php"> Login </a>';
                        }
                        ?>
                    </li>


            </ul>
	</div>
        
        <h1>Please Select Your Player Piece</h1>
            <form id="form2" action="PieceSelectPHP.php" method="get">
                Player 1 Name: <input name="Player1" type="text"/><br><br>
                Player 2 Name: <input name="Player2" type="text"/><br><br>
                Player 3 Name: <input name="Player3" type="text"/><br><br>
                Player 4 Name: <input name="Player4" type="text"/><br><br>

                <input class="button" name="Submit" type="submit" />
            </form>
 
        
        

        

    </body>
</html>
