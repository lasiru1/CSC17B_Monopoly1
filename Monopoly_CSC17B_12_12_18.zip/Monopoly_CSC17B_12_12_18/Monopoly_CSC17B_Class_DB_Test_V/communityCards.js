
function comCards()
{	
	//let comCardDisplay = document.getElementById("comCardDisplayOnScreen").innerHTML = "<img src='CommunityChest/0.png'>";
	let cardGenerator = Math.floor((Math.random()*15));		
	
	let comCardDisplay = document.getElementById("comCardDisplayOnScreen").innerHTML = "<img src='CommunityChest/"+cardGenerator+".png'>";
	document.getElementById("comCardDisplayOnScreen").innerHTML=comCardDisplay;
	return cardGenerator;	
}

function comCardEffect()
{
	
	let cardGeneratorFinal = comCards();	
	let x = checkPlyrTurn();
	
	
	switch(cardGeneratorFinal)			//community card effects
	{
		case 0:	 						//collect $100
			newMoney(100);
		break;
		case "1": 						//subract $50
			newMoney(-50);
		break;
		case "2": 						//pay $150
			newMoney(-150);
		break;
		case "3": 						//collect $100
			newMoney(100);
		break;
		case "4": 						//go to jail
			sendToJail()
		break;
		case "5": 						//collect $45
			newMoney(45);
		break;
		case "6": 						//pay everyone 50
			payAllPlyrsfifty();
		break;
		case "7": 						//pay for houses/hotels
			if(plyrHaveHouses())
			{
				comPlyrHouse();
			}
			if(plyrHaveHotels())
			{
				comPlyrHotel();
			}
		break;
		case "8": 					//collect $20
			newMoney(20);
		break;
		case "9": 					//collect $200
			newMoney(200);
		break;
		case "10": 					//jail card
 			givePlyrJCard();
		break;
		case "11": 					//collect $10
			newMoney(10);
		break;
		case "12": 					//collect $100
			newMoney(100);
		break;
		case "13": 					//advance to go
			advanceGo();
		break;
		case "14": 					//pay $100
			newMoney(-100);
		break;
		case "15": 					//collect $25
			newMoney(250);
		break;
		default:

		break;

	}		
}