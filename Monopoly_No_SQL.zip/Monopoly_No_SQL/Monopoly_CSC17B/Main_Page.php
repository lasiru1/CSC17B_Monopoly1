<?php
//Thise PHP functions gets the contents of the form from PieceSelect and stores them


// define variables and set to empty values
    $Plyr1 = $Plyr2 = $Plyr3 = $Plyr4 = $JSON = "";

    //Gets the selection
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $Plyr1 = test_input($_POST["Plyr1"]);
        $Plyr2 = test_input($_POST["Plyr2"]);
        $Plyr3 = test_input($_POST["Plyr3"]);
        $Plyr4 = test_input($_POST["Plyr4"]);

    }

    function test_input($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }


    $JSON = $Plyr1."&".$Plyr2."&".$Plyr3."&".$Plyr4;

    setcookie("plyrsPiece", $JSON, time() + (86400 * 2), "/"); // 86400 = 1 day




?>

<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
   

    <head>
        <title>Monopoly</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" type="text/css" href="CSS_File.css">
        <script type="text/javascript" src="Game.js"></script>
        <script type="application/ecmascript" src="rules.js"></script>
        <script type="application/ecmascript" src="properties.js"></script>
        <script type="text/javascript" src="communityCards.js"></script>
        <script type="text/javascript" src="chanceCards.js"></script>

    </head>
    <body>

            <div id="menuWrap">
                <div class="menuPos">
                    <ul>
      
                        <li><a  href="#Roll" onclick="diceRoll()" class="showing" id="roll">Roll</a></li>
                        <li ><a  href="#Buy" class="hidable" onclick="buyProp()" id="buy">Buy</a></li>
                        <li ><a  href="#Pass" class="hidable" id="pass" onclick="pass()">Pass</a></li>
                        <!--
                        <li ><a  href="#Properties" class="hidable" id="sell">Sell</a></li>
                        -->
                    </ul>
                    
                    <div class="alert">
                        <span class="closebtn"></span> 
                        <h3 id="messageboard"></h3>
                    </div>
                    
                    

                </div>
            </div>



        <div id="board_image"> 
            
            
            <div id="Table_ScoreWrap">
                <table class="Table_ScorePos">
                    <tr><td id="plyr0"></td><td id="plyrM0"></td></tr>
                    <tr><td id="plyr1"></td><td id="plyrM1"></td></tr>
                    <tr><td id="plyr2"></td><td id="plyrM2"></td></tr>
                    <tr><td id="plyr3"></td><td id="plyrM3"></td></tr>
                    <tr><td><img class="imagee" id="tilePic" src="BoardCards/0.png"></td></tr>
                    <tr><td id="picCaption">Game Start</td></tr>
                </table>
            </div>
            

            
            <table id="board_TopLeftCorner">
                    <tr>
                        <td id="cell20"><img class="imgSize" src="" alt="" id="img200"> <img class="imgSize" src="" alt="" id="img201"> <img class="imgSize" src="" alt="" id="img202"> <img class="imgSize" src="" alt="" id="img203"></td>
                    </tr>
            </table>

            <table id="board_TopMiddleRow">
                    <tr>
                        <td id="cell21"><img class="imgSize" src="" alt="" id="img210"> <img class="imgSize" src="" alt="" id="img211"> <img class="imgSize" src="" alt="" id="img212"> <img class="imgSize" src="" alt="" id="img213"></td>
                        <td id="cell22"><img class="imgSize" src="" alt="" id="img220"> <img class="imgSize" src="" alt="" id="img221"> <img class="imgSize" src="" alt="" id="img222"> <img class="imgSize" src="" alt="" id="img223"></td>
                        <td id="cell23"><img class="imgSize" src="" alt="" id="img230"> <img class="imgSize" src="" alt="" id="img231"> <img class="imgSize" src="" alt="" id="img232"> <img class="imgSize" src="" alt="" id="img233"></td>
                        <td id="cell24"><img class="imgSize" src="" alt="" id="img240"> <img class="imgSize" src="" alt="" id="img241"> <img class="imgSize" src="" alt="" id="img242"> <img class="imgSize" src="" alt="" id="img243"></td>
                        <td id="cell25"><img class="imgSize" src="" alt="" id="img250"> <img class="imgSize" src="" alt="" id="img251"> <img class="imgSize" src="" alt="" id="img252"> <img class="imgSize" src="" alt="" id="img253"></td>
                        <td id="cell26"><img class="imgSize" src="" alt="" id="img260"> <img class="imgSize" src="" alt="" id="img261"> <img class="imgSize" src="" alt="" id="img262"> <img class="imgSize" src="" alt="" id="img263"></td>
                        <td id="cell27"><img class="imgSize" src="" alt="" id="img270"> <img class="imgSize" src="" alt="" id="img271"> <img class="imgSize" src="" alt="" id="img272"> <img class="imgSize" src="" alt="" id="img273"></td>
                        <td id="cell28"><img class="imgSize" src="" alt="" id="img280"> <img class="imgSize" src="" alt="" id="img281"> <img class="imgSize" src="" alt="" id="img282"> <img class="imgSize" src="" alt="" id="img283"></td>
                        <td id="cell29"><img class="imgSize" src="" alt="" id="img290"> <img class="imgSize" src="" alt="" id="img291"> <img class="imgSize" src="" alt="" id="img292"> <img class="imgSize" src="" alt="" id="img293"></td>
                    </tr>

            </table>
            
            <table id="board_TopRightCorner">
                    <tr>
                        <td id="cell30"><img class="imgSize" src="" alt="" id="img300"> <img class="imgSize" src="" alt="" id="img301"> <img class="imgSize" src="" alt="" id="img302"> <img class="imgSize" src="" alt="" id="img303"></td>
                    </tr>
            </table>


            <table id="board_MiddleRows">
                    <tr>
                        <td id="cell19"><img class="imgSize" src="" alt="" id="img190"> <img class="imgSize" src="" alt="" id="img191"> <img class="imgSize" src="" alt="" id="img192"> <img class="imgSize" src="" alt="" id="img193"></td>
                        <td></td><td></td><td></td><td></td><td></td>
                        <td id="cell31"><img class="imgSize" src="" alt="" id="img310"> <img class="imgSize" src="" alt="" id="img311"> <img class="imgSize" src="" alt="" id="img312"> <img class="imgSize" src="" alt="" id="img313"></td>
                    </tr>
                    <tr>
                        <td id="cell18"><img class="imgSize" src="" alt="" id="img180"> <img class="imgSize" src="" alt="" id="img181"> <img class="imgSize" src="" alt="" id="img182"> <img class="imgSize" src="" alt="" id="img183"></td>
                        <td id="comCardDisplayOnScreen"></td><td></td><td></td><td></td><td></td>
                        <td id="cell32"><img class="imgSize" src="" alt="" id="img320"> <img class="imgSize" src="" alt="" id="img321"> <img class="imgSize" src="" alt="" id="img322"> <img class="imgSize" src="" alt="" id="img323"></td>
                    </tr>
                    <tr>
                        <td id="cell17"><img class="imgSize" src="" alt="" id="img170"> <img class="imgSize" src="" alt="" id="img171"> <img class="imgSize" src="" alt="" id="img172"> <img class="imgSize" src="" alt="" id="img173"></td>
                        <td></td><td></td><td></td><td></td><td></td>
                        <td id="cell33"><img class="imgSize" src="" alt="" id="img330"> <img class="imgSize" src="" alt="" id="img331"> <img class="imgSize" src="" alt="" id="img332"> <img class="imgSize" src="" alt="" id="img333"></td>
                    </tr>
                    <tr>
                        <td id="cell16"><img class="imgSize" src="" alt="" id="img160"> <img class="imgSize" src="" alt="" id="img161"> <img class="imgSize" src="" alt="" id="img162"> <img class="imgSize" src="" alt="" id="img163"></td>
                        <td></td><td></td><td></td><td></td><td></td>
                        <td id="cell34"><img class="imgSize" src="" alt="" id="img340"> <img class="imgSize" src="" alt="" id="img341"> <img class="imgSize" src="" alt="" id="img342"> <img class="imgSize" src="" alt="" id="img343"></td>
                    </tr>
                    <tr>
                        <td id="cell15"><img class="imgSize" src="" alt="" id="img150"> <img class="imgSize" src="" alt="" id="img151"> <img class="imgSize" src="" alt="" id="img152"> <img class="imgSize" src="" alt="" id="img153"></td>
                        <td></td><td></td><td></td><td></td><td></td>
                        <td id="cell35"><img class="imgSize" src="" alt="" id="img350"> <img class="imgSize" src="" alt="" id="img351"> <img class="imgSize" src="" alt="" id="img352"> <img class="imgSize" src="" alt="" id="img353"></td>
                    </tr>
                    <tr>
                        <td id="cell14"><img class="imgSize" src="" alt="" id="img140"> <img class="imgSize" src="" alt="" id="img141"> <img class="imgSize" src="" alt="" id="img142"> <img class="imgSize" src="" alt="" id="img143"></td>
                        <td></td><td></td><td></td><td></td><td></td>
                        <td id="cell36"><img class="imgSize" src="" alt="" id="img360"> <img class="imgSize" src="" alt="" id="img361"> <img class="imgSize" src="" alt="" id="img362"> <img class="imgSize" src="" alt="" id="img363"></td>
                    </tr>
                    <tr>
                        <td id="cell13"><img class="imgSize" src="" alt="" id="img130"> <img class="imgSize" src="" alt="" id="img131"> <img class="imgSize" src="" alt="" id="img132"> <img class="imgSize" src="" alt="" id="img133"></td>
                        <td></td><td></td><td id ="chanCardDisplayOnScreen"></td><td ></td><td></td>
                        <td id="cell37"><img class="imgSize" src="" alt="" id="img370"> <img class="imgSize" src="" alt="" id="img371"> <img class="imgSize" src="" alt="" id="img372"> <img class="imgSize" src="" alt="" id="img373"></td>
                    </tr>
                    <tr>
                        <td id="cell12"><img class="imgSize" src="" alt="" id="img120"> <img class="imgSize" src="" alt="" id="img121"> <img class="imgSize" src="" alt="" id="img122"> <img class="imgSize" src="" alt="" id="img123"></td>
                        <td></td><td></td><td></td><td></td><td></td>
                        <td id="cell38"><img class="imgSize" src="" alt="" id="img380"> <img class="imgSize" src="" alt="" id="img381"> <img class="imgSize" src="" alt="" id="img382"> <img class="imgSize" src="" alt="" id="img383"></td>
                    </tr>
                    <tr>
                        <td id="cell11"><img class="imgSize" src="" alt="" id="img110"> <img class="imgSize" src="" alt="" id="img111"> <img class="imgSize" src="" alt="" id="img112"> <img class="imgSize" src="" alt="" id="img113"></td>
                        <td></td><td></td><td></td><td></td><td></td>
                        <td id="cell39"><img class="imgSize" src="" alt="" id="img390"> <img class="imgSize" src="" alt="" id="img391"> <img class="imgSize" src="" alt="" id="img392"> <img class="imgSize" src="" alt="" id="img393"></td>
                    </tr>
            </table>  


            <table id="board_BottomLeftCorner">
                    <tr>
                        <td id="cell10"><img class="imgSize" src="" alt="" id="img100"> <img class="imgSize" src="" alt="" id="img101"> <img class="imgSize" src="" alt="" id="img102"> <img class="imgSize" src="" alt="" id="img103"></td>
                    </tr>
            </table>    

            <table id="board_LastMiddleRow">
                    <tr>
                        <td id="cell9"><img class="imgSize" src="" alt="" id="img90"> <img class="imgSize" src="" alt="" id="img91"> <img class="imgSize" src="" alt="" id="img92"> <img class="imgSize" src="" alt="" id="img93"></td>
                        <td id="cell8"><img class="imgSize" src="" alt="" id="img80"> <img class="imgSize" src="" alt="" id="img81"> <img class="imgSize" src="" alt="" id="img82"> <img class="imgSize" src="" alt="" id="img83"></td>
                        <td id="cell7"><img class="imgSize" src="" alt="" id="img70"> <img class="imgSize" src="" alt="" id="img71"> <img class="imgSize" src="" alt="" id="img72"> <img class="imgSize" src="" alt="" id="img73"></td>
                        <td id="cell6"><img class="imgSize" src="" alt="" id="img60"> <img class="imgSize" src="" alt="" id="img61"> <img class="imgSize" src="" alt="" id="img62"> <img class="imgSize" src="" alt="" id="img63"></td>
                        <td id="cell5"><img class="imgSize" src="" alt="" id="img50"> <img class="imgSize" src="" alt="" id="img51"> <img class="imgSize" src="" alt="" id="img52"> <img class="imgSize" src="" alt="" id="img53"></td>
                        <td id="cell4"><img class="imgSize" src="" alt="" id="img40"> <img class="imgSize" src="" alt="" id="img41"> <img class="imgSize" src="" alt="" id="img42"> <img class="imgSize" src="" alt="" id="img43"></td>
                        <td id="cell3"><img class="imgSize" src="" alt="" id="img30"> <img class="imgSize" src="" alt="" id="img31"> <img class="imgSize" src="" alt="" id="img32"> <img class="imgSize" src="" alt="" id="img33"></td>
                        <td id="cell2"><img class="imgSize" src="" alt="" id="img20"> <img class="imgSize" src="" alt="" id="img21"> <img class="imgSize" src="" alt="" id="img22"> <img class="imgSize" src="" alt="" id="img23"></td>
                        <td id="cell1"><img class="imgSize" src="" alt="" id="img10"> <img class="imgSize" src="" alt="" id="img11"> <img class="imgSize" src="" alt="" id="img12"> <img class="imgSize" src="" alt="" id="img13"></td>
                    </tr>

            </table>

            <table id="board_BottomRightCorner">
                    <tr>
                        <td id="cell0"><img class="imgSize" src="" alt="" id="img00"> <img class="imgSize" src="" alt="" id="img01"> <img class="imgSize" src="" alt="" id="img02"> <img class="imgSize" src="" alt="" id="img03"></td>
                    </tr>
            </table>

        
        </div>
        
<?php
    //Thise PHP functions gets the contents of the form from PieceSelect and stores them
    
    /*



        $JSON = $Plyr1.";".$Plyr1.";".$Plyr1.";".$Plyr1;

      

        echo "<h2>Your Input:</h2>";
        echo $Plyr1;
        echo "<br>";
        echo $Plyr2;
        echo "<br>";
        echo $Plyr3;
        echo "<br>";
        echo $Plyr4;
        echo "<br>";
        echo $JSON;
        */

    ?>

        
    </body>
</html>
