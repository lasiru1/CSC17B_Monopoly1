
function chanCards()
{
	//let chanCardDisplay = document.getElementById("chanCardDisplayOnScreen").innerHTML = "<img src='Chance/0.png'>";	
	let cardGenerator = Math.floor((Math.random()*15));

	let chanCardDisplay = document.getElementById("chanCardDisplayOnScreen").innerHTML = "<img src='chance/"+cardGenerator+".png'>";
	document.getElementById("chanCardDisplayOnScreen").innerHTML=chanCardDisplay;
	return cardGenerator;
}

function chanCardEffect()			//effects for chance cards.
{
	
	let cardGeneratorFinal = chanCards();
	let y = checkPlyrTurn();
	
	console.log("Got the card num "+cardGeneratorFinal);
	switch(cardGeneratorFinal)
	{
		case "0": 							//go to reading railroad
			if(plyrPositionCheck() >= 5) {	
				newMoney(200);
			}
			movePlyr(5);

		break;
		case "1": 							//collect $50
			newMoney(50);

		break;
		case "2": 							//get out of jail card
			givePlyrJCard();

		break;
		case "3":   						//pay for houses/hotels
			if(plyrHaveHouses()) {
				chancePlyrHouse();
			}
			if(plyrHaveHotels()) {
				chancePlyrHotel();
			}

		break;
		case "4": 						//lost $15
			newMoney(-15);

		break;
		case "5": 					//go to nearest railroad
			if(plyrPositionCheck() < 5 || plyrPositionCheck() >= 35)
			{								
				if (plyrPositionCheck() >= 35) {
					newMoney(200);
				}
				moveplyr(5);
				break;
			}
			else if (plyrPositionCheck() < 15) {
				 moveplyr(15);
				break;
			}
			else if (plyrPositionCheck() < 25) {
				 moveplyr(25);
				break;
			}
			else if (plyrPositionCheck() < 35) {
				 moveplyr(35);
				break;
			}

		break;			
		case "6": 					//pay every playaer $50
			payAllPlyrsfifty();

		break;
		case "7": 					//go back 3 spaces
			moveplyr(-3);

		break;
		case "8": 					//go to jail
			sendToJail();
		break;
		case "9":
			moveplyr(24); 		//go to illinois ave
			if (plyrPositionCheck() >= 24) {
				newMoney(200);
			}
		break;
		case "10": 				//go to position go
			moveplyr(0);
			newMoney(200);
		break;
		case "11": 					//go to nearest utility
			if (plyrPositionCheck() < 12 || plyrPositionCheck() >= 28 ) {
				if (plyrPositionCheck() >= 28) {
					newMoney(200);
				}
				moveplyr(12);	
				break;			
			}
			if (plyrPositionCheck() >= 12) {
				movePlyr(28);
			}
		break;
		case "12": 					//collect $150
			newMoney(150);
		break;
		case "13":
			if (plyrPositionCheck() >= 11 ) {				
					newMoney(200);
				}
				movePlyr(11);			
		break;
		case "14": 				//go to boardwalk
			moveplyr(39);
		break;
		case "15": 					//go to nearest railroad
			if(plyrPositionCheck() < 5 || plyrPositionCheck() >= 35) {								
				if (plyrPositionCheck() >= 35) {
					newMoney(200);
				}
				moveplyr(5);
				break;
			}
			else if (plyrPositionCheck() < 15) {
				 moveplyr(15);
				break;
			}
			else if (plyrPositionCheck() < 25) {
				 moveplyr(25);
				break;
			}
			else if (plyrPositionCheck() < 35) {
				 moveplyr(35);
				break;
			}
		break;
		default:

		break;
	}
}
		