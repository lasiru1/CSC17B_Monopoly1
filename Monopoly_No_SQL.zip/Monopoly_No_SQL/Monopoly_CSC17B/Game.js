/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

//Declaring global variable
var player = [];
var plyrTurn;


//Players Properties
function plyrsProp(){
    this.piece = " ",
    this.position = 0,        
    this.money = 1500,
    this.jailCards =  0,    
    this.inJail = false,
    this.housesBought = 0,
    this.hotelsBought = 0,
    this.lastRoll1=0,
    this.lastRoll2=0,
    this.jailTime=0,
    this.prevDbles=0; // keeps track of the successive doubles thrown
    
}

function getForm(url){
    var info=url.split("?");
    var nameValuePairs=info[1].split("&");
    var $_GET = new Object;
    for(var i=0;i<nameValuePairs.length-1;i++){
        var map=nameValuePairs[i].split("=");
        
        var name=map[0];
        var value=map[1];
        $_GET[name]=value;        
    }    
    return $_GET;
} 
    
function diceRoll()
{
    //console.log("used this function");
    //after all four players have gone then it resets the counter back to player 1 or zero
    plyrTurn++;
    if(plyrTurn===4){
        plyrTurn=0;
    }    
    
    die1 = Math.floor(Math.random() * 6) + 1; //First Dice
    die2 = Math.floor(Math.random() * 6) + 1; //Second Dice
    //stores the players last two dice rolls
    player[plyrTurn].lastRoll1=die1;
    player[plyrTurn].lastRoll2=die2;
    
    if(die1==die2){
        //if double
        //check how many doubles have happened
        player[plyrTurn].prevDbles++;
        checkDbles(); // found below
        //do we want to have them get to spend their turn in jail if 3 successive 
        //doubles? or does that first turn not count?
    }else{
        //the sequence of doubles is broken
        player[plyrTurn].prevDbles=0;
    }
    
    if(isPlyrJailed()){
        //player is in jail
        //does jail rules
        //found in rules.js
        //displayTile();
        inJail();
        
    }else{
        //player is not in jail so make regular movement
        useDice(); // defined below, basically use the rolls to move positions of pieces
        //check what landed on and do actions
        landOnTile(player[plyrTurn]);
        //change the tile on the side to the current card
        displayTile();
    }
    
        
};
function checkDbles(){
    //checks to see if the previous roll was also a double
    //if three doubles in a row send to jail
    if(player[plyrTurn].prevDbles==3){
        sendToJail();
    }
}
function useDice(){
    //gets rid of the piece at the old position
    var temp=player[plyrTurn].position; //gets the previous position
    document.getElementById("img"+temp+plyrTurn).src= "Pieces/blank.png";
    //document.getElementById("img"+temp+plyrTurn).visibility=hidden;
    //Erases its previous position
    //uses dice roll to move the amount
    var die1= player[plyrTurn].lastRoll1;
    var die2= player[plyrTurn].lastRoll2;
    player[plyrTurn].position += die1+die2; //Assign its position to the current player    
        //Checks to see if the player passes go it resets to 0
        if(player[plyrTurn].position>=40)
        {
            var temp=player[plyrTurn].position;
            temp-=40;                //Subtract 40 to get the remaining position
            player[plyrTurn].position=temp; //assign the new postion 
        }

        var rolled=die1+die2; //Gets what the current player has rolled
        document.getElementById("messageboard").innerHTML="Player "+(plyrTurn+1)+" Rolled "+ rolled+" and landed on "+player[plyrTurn].position;
        var temp=player[plyrTurn].position;
        document.getElementById("img"+temp+plyrTurn).src= player[plyrTurn].piece;
        //document.getElementById("img"+temp+plyrTurn).visibility=visible;
    //Assign its new position
}
function displayTile(){
    //displays/ updates the current tile on the right hand side

    var currPos =player[plyrTurn].position;
    console.log("showing Tile");
    var pic = document.getElementById("tilePic");
    var caption =document.getElementById("picCaption");
    //var cell = document.getElementById(location);
    pic.setAttribute("src", "BoardCards/"+currPos+".png");
    caption.innerHTML=player[plyrTurn].name+" landed on: "+properties[currPos].name;
    
    
}


window.onload = function(){
    plyrTurn = -1; //Increment for when a play makes a turn
    // neg. one since rolling increments the turn before starting so as to allow things to make sence
    playercount = 4;
    
    //Fills the cells from 1-39  with blank pics
    for(var x=0; x<4; x++){
        for(var i=1; i<40; i++){    //(img=name)(i=cell from 1-39)(x=Player from 0-3)
            document.getElementById("img"+i+x).src= "Pieces/blank.png";

        }
    }
    
    for(var i=0; i<4; i++){

        player[i] = new plyrsProp(); //Creating the number of players    
       
    }
    player[0].piece="Pieces/Thimble.png";
    player[1].piece="Pieces/Racecar.png";
    player[2].piece="Pieces/Battleship.png";
    player[3].piece="Pieces/Hat.png";    
    
    document.getElementById("img00").src= "Pieces/Thimble.png";    //Print the starting position
    document.getElementById("img01").src= "Pieces/Racecar.png";    //Print the starting position
    document.getElementById("img02").src= "Pieces/Battleship.png"; //Print the starting position
    document.getElementById("img03").src= "Pieces/Hat.png";        //Print the starting position    
    
    var name,i;// x holds the name and i is the counter
    i=0;
    var url=document.location.href;
    $_GET=getForm(url);
    for(name in $_GET){
        player[i].name=decodeURIComponent($_GET[name]); // Sets the name to each player
        i++;
    }   
    
    for(var i=0; i<4; i++)
    {
        document.getElementById("plyr"+i).innerHTML= player[i].name+": ";    //Print the name of each player
        document.getElementById("plyrM"+i).innerHTML= "$"+player[i].money;    //Print the money of each player
    }
    
};
function updateScore(){
    //changes the scores on the top right of the screen
    for(var i=0; i<4; i++)
    {
        document.getElementById("plyr"+i).innerHTML= player[i].name+": ";    //Print the name of each player
        document.getElementById("plyrM"+i).innerHTML= "$"+player[i].money;    //Print the money of each player
    }    
}
                                //functions for general gameplay
function newMoney(changeMoney){  //adds money to current player
    var addMoney = changeMoney;
    player[plyrTurn].money += addMoney;
}
function currentPlyrMoney()     //checks current players money
{
    return player[plyrTurn].money;
}   
function checkPlyrTurn()        //returns current player 
{
    return plyrTurn;
}  
function plyrPositionCheck()  //checks current player position
{
    return player[plyrTurn].position;
}
function sendToJail()           //sends current player to jail
{
    //initially get rid of the piece at the previous position
    var pos =player[plyrTurn].position;
    document.getElementById("img"+pos+plyrTurn).src= "Pieces/blank.png";
    
    //places the piece at the jail tile
    player[plyrTurn].inJail = true;
    player[plyrTurn].position = 10;
    pos =player[plyrTurn].position;
    document.getElementById("img"+pos+plyrTurn).src= player[plyrTurn].piece;     
}
function movePlyr(newPos)     //moves current player to new position
{
    var newPosition = newPos;
    player[plyrTurn].position = newPosition;
}
function isPlyrJailed()       //checks if current player is jailed
{
    if(player[plyrTurn].inJail === true)
    {
        console.log("player had in jail as true");
        return true;
    }
    else{
        console.log("player had in jail as false");
        return false;
}
}
function givePlyrJCard()      //gives player jail card
{
    player[plyrTurn].jailCards+= 1;
}
function plyrHaveHouses()     //checks if current player has houses
{
    if(player[plyrTurn].housesBought > 0)   
        return true;    
    else
        return false;
}
function chancePlyrHouse()      //chance card houses pay
{
    player[plyrTurn].money -= player[plyrTurn].housesBought * 25;
}
function comPlyrHouse()         //community card houses pay
{
    player[plyrTurn].money -= player[plyrTurn].housesBought * 40;
}
function plyrHaveHotels()     //checks if current player has hotels
{
    if(player[plyrTurn].hotelsBought > 0)   
        return true;    
    else
        return false;
}
function chancePlyrHotel()  //chance card hotels pay
{
    player[plyrTurn].money -= player[plyrTurn].hotelsBought * 100;
}
function comPlyrHotel()     //community card hotels pay
{
    player[plyrTurn].money -= player[plyrTurn].hotelsBought * 115;
}
function payAllPlyrsfifty() //deducts from current and adds to all
{
    player[plyrTurn].money -= 250;
    player[0].money += 50;
    player[1].money += 50;
    player[2].money += 50;
    player[3].money += 50;
}
function payOtherPlyr()       //pays other player and deducts current player, used for paying rent
{
    var plyrOwnedProp = getPropOwner();
    var amnt = getPlyrRent();
    
    console.log("The owner now had"+player[plyrOwnedProp].money);
    console.log("The the visiter now had"+player[plyrTurn].money);
    player[plyrOwnedProp].money += amnt;
    player[plyrTurn].money -= amnt;
    console.log("The owner now has"+player[plyrOwnedProp].money);
    console.log("The the visiter now has"+player[plyrTurn].money);
    updateScore();
}
function advanceGo()                //automatically advances to go, for community/chance
{
    movePlayer(0);
    newMoney(200);
}
function sellProperty()
{

}
