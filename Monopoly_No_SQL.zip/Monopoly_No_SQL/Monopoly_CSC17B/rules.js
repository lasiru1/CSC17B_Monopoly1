/*
-Jail 
You land in Jail when...

Your token lands on the space marked "Go to Jail"
You draw a card marked "Go to Jail" or
You throw doubles three times in succession.


Throwing doubles on any of your next three turns. (if you succeed in doing this you immediately move forward the number of spaces shown by your doubles throw. Even though you had thrown doubles, you do not take another turn.)

Using a "Get Out of Jail Free Card"
Purchasing the "Get Out of Jail Free Card" from another player and playing it.

Paying a fine of $50 before you roll the dice on either of your next two turns.

If you do not throw doubles by your third turn, you must pay the $50 fine. You then get out of Jail and immediately move forward the number of spaces shown by your throw. (Even though you are in Jail, you may buy and sell property, buy and sell houses and hotels and collect rents.)
-Buying 

-Adding houses 

-Pausing the game 

-win conditions(20 rounds or when everyone else no money)


*/
function manipProperty(currPlayer,game){
    // trading to players?
}

//which prop
//which player

function landOnTile(curPlyr){
    /*
    console.log("landed on some shit;");
    // lands on/pass go--- this should go in the player movement function
    // ^^^ not gonna be in this func
    console.log("Player's Shit: ");
    console.log("piece: "+curPlyr.piece);
    console.log("hotelsbought: "+curPlyr.hotelsBought);
    console.log("housesbought: "+curPlyr.housesBought);
    console.log("inJail: "+curPlyr.inJail);
    console.log("jailcards: "+curPlyr.jailCards);
    console.log("money: "+curPlyr.money);
    console.log("name: "+curPlyr.name);
    console.log("Injail: "+curPlyr.inJail);
    */
    console.log("Position: "+curPlyr.position);
   // console.log("the property landed on is: "+properties[curPlyr.position].name);
   
    var currProp=properties[curPlyr.position];
    //console.log("the property landed on is(after): "+currProp.name);
    console.log("property stuff:"+currProp.group);
    //Lands on a Chance/community 
    if(currProp.group=='etc'){
        console.log("on a etc tile");
        if(currProp.type=="community"){
            comCardEffect();
        }else if(currProp.type=="chance"){
            chanCardEffect();
        }
    }else if(currProp.group=='tax'){
        //Lands on luxary/incomtax
        console.log("on a tax tile");
        var mustPay= returnPropCost();
        //have the cost of the tax thing
        //so bo have to check if they can pay it
        
        //while(!canPayFee()){
            //if they cant pay it they have to mortgage a property
            //if no more properties break out and still under then the player loses
        //}
        //if player can pay the fee then pays
        newMoney(-1 * (mustPay));
        //loses the money
    //Lands on gotojail/jailtile
    }else if(currProp.group=='jail'){
        if(currProp.name=='Go To Jail'){
            //you're being sent to jail!
            sendToJail();
        }
        console.log("on a jail tile");
    
    // Lands on a property
    }else{
        console.log("landed on an actual property");
        if(checkPlyrPosForProp()){
            console.log("not owned");
            showBuySell();
            // owned by none
            // Want to buy?h
            //y/N
            // if Y
                //subtract money of the property from player if equal
                // give prop or do nada depending
            //else
                //nada
        }else{
            console.log("the property is owned");            
            console.log("check if can pay");
            if(checkIfPayRent()){
                    payOtherPlyr();
                    console.log("paid player");
                }
           // else
           // {
           //     if(canMortProp())
            //    {
                    showMortTile();
            //        do{

            //        }
             //       while(//button hasnt been clicked
            //                )
            //        hideMortTile();
            //    } 
            //    else{
                        //has no houses to sell and not enough money
                        //player is out for the count
                        //gives remaining money to the owner
            //    }
          //  } 
                
                  
               // break;
            //}while(true);
            //owned by someone
            //check who owned by
            // make this a do while(player==active or playermoney<=propertiecost){}
                //make this check into a function
                // if property >0
                
                //else
                    //player active =false
                // make player sell properties
            //if active
                //subtract away the amount of the property
                //give total amount to the owner of the prop
            //else
                //subtract away the amount of the property
                //give difference(the nonneg part) to the owner of the prop
        }
    }  
}
function canPay(){
    
    //return true;
    
    //return false;
}
function showRoll(){
    var roll = document.getElementById("roll");
    roll.setAttribute("class", "showing");
}
function hideRoll(){
    var roll = document.getElementById("roll");
    roll.setAttribute("class", "hidable");
}
function showBuySell(){
    console.log("showing");
    var buy = document.getElementById("buy");
    var pass =document.getElementById("pass");
    //var cell = document.getElementById(location);
    buy.setAttribute("class", "showing");
    pass.setAttribute("class", "showing");
    hideRoll();    
}
function showMortTile()
{

}
function hideMortTile()
{

}
function hideBuySell(){
    console.log("hiding");
    //document.getElementById("buy").visibility= hidden;
    //document.getElementById("pass").visibility= hidden;
    var buy = document.getElementById("buy");
    var pass =document.getElementById("pass");
    //var cell = document.getElementById(location);
    buy.setAttribute("class", "hidable");
    pass.setAttribute("class", "hidable");
    showRoll();
}
function inJail(){
    //if player has get out of jail free card
        //player loses get out of jail free card
        // isinjail=false
    console.log("YOU'RE IN JAIL BUDDY");
    var criminal=player[plyrTurn];
    var TinJail=criminal.jailTime;
    var pRoll1 = criminal.lastRoll1;
    var pRoll2 = criminal.lastRoll2;
    if(pRoll1 == pRoll2){
        console.log("YOU ROLLED DOUBLES");
        //rolled a double so gets to leave jail and move forward the rolled amount immediately
        player[plyrTurn].inJail=false;
        player[plyrTurn].jailTime=0;
        useDice();
        landOnTile();
        displayTile();
    }else if(TinJail ==3){
        console.log("TIMES UP");
        //been in jail for 3 turns
        //loses 50 bucks but gets to move immediately
        player[plyrTurn].inJail=false;
        player[plyrTurn].jailTime=0;
        newMoney(-1 * (50));
        useDice();
        landOnTile();
        displayTile();
    }else{ 
        player[plyrTurn].jailTime++;
    }

    
}
function gameOver(allPlayers, roundnumber){
    //for all players in allplayers
        //if properties = 0 and money==0 (or make a players.active)
            //nada
        //else
            //playersleft++
    //if playersleft ==1
        //game over
    //else
        //keep playing
    //if round number is =20
        //game over
    //if round numer<=20
        //keep playing
}